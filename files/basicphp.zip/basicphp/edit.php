<?php 
include_once('db/db.php');
$event = '';
 // edit record 
 if(isset($_GET['id']))
 {
 	$id = $_GET['id'];
 	$row = mysql_fetch_object(mysql_query("SELECT * FROM tbstudent WHERE id = '$id'"));
 }
 // end edit record 
if(isset($_POST['update']))
{
    $id          = $_GET['id'];
    $studentname = $_POST['studentname'];
    $gender      = $_POST['gender'];
    $dob         = $_POST['dob'];
    $pob         = $_POST['pob'];
    $address     = $_POST['address'];
    $phone       = $_POST['phone'];
    $status      = $_POST['status'];

    mysql_query("UPDATE tbstudent
                        SET student_name = '$studentname',
                            gender       = '$gender',
                            dob          = '$dob',
                            pob          = '$pob',
                            address      = '$address',
                            phone        = '$phone',
                            status       = '$status' 
                        WHERE id = '$id'");
    
    header('location:index.php');
}



?>
<!DOCTYPE html>
<html>
<head>
	<title>List Student</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">	
</head>
<body>
  <div class="container" style="background-color:#eee">
        <div class="header">
        	<center>
        	     <h2 style="color:red">Student Information</h2>
        	     <h4 style="color:red"><?php if(isset($event)){echo $event;}?></h4>

        	</center>

        </div>
        <form action="" method="post">
        <table class="table">
        	<tr>
        		<td>
        			<label>StudentName</label>
        			<input type="text" name="studentname" value="<?= $row->student_name ?>" class="form-control">
        		</td>
        		<td>
        			<label>Gender</label>
        			<select name="gender" class="form-control">
        				<option value="1" <?php if($row->gender == 1){ echo "selected='selected'"; } ?>>Male</option>
        				<option value="0" <?php if($row->gender == 0){ echo "selected='selected'"; } ?>>Female</option>
        			</select>
        		</td>
        	</tr>
        	<tr>
        		<td>
        			<label>Date Of Birth</label>
        			<input type="date" value="<?= $row->dob ?>" class="form-control" name="dob">
        		</td>
        		<td>
        			<label>Place Of Birth</label>
        			<textarea class="form-control" name="pob"><?= $row->pob ?></textarea>
        		</td>
        	</tr>
        	<tr>        		
        		<td>
        			<label>Phone</label>
        			<input type="number" class="form-control"  value="<?= $row->phone ?>" name="phone">
        		</td>
        		<td>
        			<label>Address</label>
        			<textarea class="form-control" name="address"><?= $row->address ?></textarea>
        		</td>
        		
        	</tr>
        	<tr>
        	    <td>
        	    	<label>Status</label>
        	    	<input checked="checked" <?php if($row->status == 1){ echo "checked='checked'"; } ?> type="radio" name="status" value="1">Active
        	    	<input type="radio" <?php if($row->status == 0){ echo "checked='checked'"; } ?> name="status" value="0">Subspend
        	    </td>
        	    <td>
        	 		<input type="submit" value="Update" name="update" class="btn btn-primary">
        	       		
        	    </td>
        	</tr>
        </table>
	</form>
	</div>
</body>
</html>