<?php 
include_once('db/db.php');
$event = '';

// delete record 
 if(isset($_GET['idd']))
 {
 	$id = $_GET['idd'];
 	mysql_query("DELETE FROM tbstudent WHERE id = '$id'");
 	$event = "Student Record ".$id." have been delete successfully!!";
 }
// end delete record 

// save record 
if(isset($_POST['register']))
{
	$studentname = $_POST['studentname'];
	$gender      = $_POST['gender'];
	$dob         = $_POST['dob'];
	$pob         = $_POST['pob'];
	$address     = $_POST['address'];
	$phone       = $_POST['phone'];
	$status      = $_POST['status'];

	mysql_query("INSERT INTO tbstudent(student_name,gender,dob,pob,address,phone,status)
		                VALUES('$studentname','$gender','$dob','$pob','$address','$phone','$status')");
    // get last id 

    $id = mysql_insert_id();

    if($id > 0)
    {
    	$event = "student name ".$studentname." have been register successfully..";
    }
}
// end save record 
?>
<!DOCTYPE html>
<html>
<head>
	<title>List Student</title>
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">	
</head>
<body>
  <div class="container" style="background-color:#eee">
        <div class="header">
        	<center>
        	     <h2 style="color:red">Student Information</h2>
        	     <h4 style="color:red"><?php if(isset($event)){echo $event;}?></h4>

        	</center>

        </div>
        <form action="" method="post">
        <table class="table">
        	<tr>
        		<td>
        			<label>StudentName</label>
        			<input type="text" name="studentname" class="form-control">
        		</td>
        		<td>
        			<label>Gender</label>
        			<select name="gender" class="form-control">
        				<option value="1">Male</option>
        				<option value="0">Female</option>
        			</select>
        		</td>
        	</tr>
        	<tr>
        		<td>
        			<label>Date Of Birth</label>
        			<input type="date" class="form-control" name="dob">
        		</td>
        		<td>
        			<label>Place Of Birth</label>
        			<textarea class="form-control" name="pob"></textarea>
        		</td>
        	</tr>
        	<tr>        		
        		<td>
        			<label>Phone</label>
        			<input type="number" class="form-control" name="phone">
        		</td>
        		<td>
        			<label>Address</label>
        			<textarea class="form-control" name="address"></textarea>
        		</td>
        		
        	</tr>
        	<tr>
        	    <td>
        	    	<label>Status</label>
        	    	<input checked="checked" type="radio" name="status" value="1">Active
        	    	<input type="radio" name="status" value="0">Subspend
        	    </td>
        	    <td><input type="submit" value="Register" name="register" class="btn btn-primary"></td>
        	</tr>
        </table>
	</form>

	<!-- list student  -->

		<table class="table">
			<thead>
				<th>ID</th>
				<th>StudentName</th>
				<th>Gender</th>
				<th>DOB</th>
				<th>POB</th>
				<th>Address</th>
				<th>Phone</th>
				<th>Status</th>
				<th>Action</th>
			</thead>
			<tbody>
				<?php 
					$liststudent = mysql_query("SELECT * FROM tbstudent");
					while($row = mysql_fetch_object($liststudent))
					{
						?>
							<tr>
								<td><?=$row->id?></td>
								<td><?=$row->student_name?></td>
								<td><?php if($row->gender){echo"Male";}else{echo"Female";}?></td>
								<td><?=$row->dob?></td>
								<td><?=$row->pob?></td>
								<td><?=$row->address?></td>
								<td><?=$row->phone?></td>
								<td><?php if($row->status){echo"Active";}else{echo"Subspend";}?></td>
								<td><a href="edit.php?id=<?= $row->id ?>">Edit</a>| <a href="index.php?idd=<?= $row->id ?>">Delete</a></td>
							</tr>
						<?php
					}
				?>
			</tbody>
		</table>
	</div>
</body>
</html>